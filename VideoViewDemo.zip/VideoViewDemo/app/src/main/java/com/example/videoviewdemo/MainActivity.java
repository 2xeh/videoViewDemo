package com.example.videoviewdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    /*
    VideoView Demo with MediaController
    There's quite a few links out there, but I particularly liked this tutorial as a reference, particularly because it uses an AsyncTask to process the video:
    http://www.oodlestechnologies.com/blogs/Working-with-MediaController%2C--VideoView-in-Android

    Do consider the following:
    Video playback may appear choppy in an emulator. If possible, test functionality on an actual device.

    Don't forget to:
        * put a video view into the layout xml
        * put an internet permission into your manifest

     AA NOTE: I just found this link that looks promising for seamless streaming during screen rotation
     due to time constraints, I was unable to incorporate it into this demo
     http://stackoverflow.com/questions/6524659/avoid-android-videoview-corruption-when-rotating-back-to-portrait
    */


    String title, description, pubDate, link;
    TextView tvTitle, tvDescriptionLabel, tvDescription, tvPubDate;
    VideoView videoView;
    VideoAsyncTask videoAsyncTask;
    MediaController mediaController;
    int stopPosition = 0;
    final int VIDEO_KEY = 42;
    android.app.ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // some data you could retreive from intent
        title = "Xenia Rubinos";
        link = "https://play.podtrac.com/npr-510292/ondemand.npr.org/npr-mp4/npr/ascvid/2016/07/20160725_ascvid_xeniarubinos-n.mp4?orgId=1&d=850&p=510292&story=487362855&t=podcast&e=487362855&ft=pod&f=510292";
        pubDate = "Mon, 25 Jul 2016";
        description = "Xenia Rubinos has learned a valuable lesson — 'You have to know where you come from to know where you're going' — and applied it to her remarkable music. Rubinos' work contains traces of her Afro-Caribbean roots, but when she and her band do things like use two bassists to play a counter-melody in her song 'Lonely Lover,' they defy. ";

        // get all the views
        tvTitle = (TextView) findViewById(R.id.tvHeader);
        tvPubDate = (TextView) findViewById(R.id.tvCaption);
        tvDescriptionLabel = (TextView) findViewById(R.id.tvDescriptionLabel);
        tvDescription = (TextView) findViewById(R.id.tvSubhead);
        videoView = (VideoView) findViewById(R.id.videoView);

        // setting data into the views
        tvTitle.setText(title);
        tvPubDate.setText(pubDate);
        tvDescription.setText(description);

        // instantiate a media controller to use
        // mediaController are the playback controls (play/pause)
        mediaController=new MediaController(MainActivity.this);

        // Start to run the video in the background
        videoAsyncTask = new VideoAsyncTask(MainActivity.this, videoView, mediaController);
        videoAsyncTask.execute(link);

    }

    @Override
    protected void onPause() {
        videoAsyncTask.cancel(true);
        super.onPause();
    }

    public void startFullscreenActivity(View view) {
        // let's pass the link to the next activity
        Intent intent = new Intent(this, FullscreenActivity.class);
        intent.putExtra("link", link);

        startActivity(intent);
    }

}
