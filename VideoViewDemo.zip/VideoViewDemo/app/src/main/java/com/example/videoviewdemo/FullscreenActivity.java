package com.example.videoviewdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.VideoView;

public class FullscreenActivity extends AppCompatActivity {

    String link;
    VideoView videoView;
    VideoAsyncTask videoAsyncTask;

    // DEMO 2: Force rotate screen
    // http://stackoverflow.com/questions/2150287/force-an-android-activity-to-always-use-landscape-mode

    // Some other considerations:
    // Look at the manifest file, line 27

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fullscreen);

        // receive intent from the calling activity
        Intent intent = getIntent();
        link = intent.getStringExtra("link");

        // get the video view
        videoView = (VideoView) findViewById(R.id.videoView);

        // Start to run the video in the background
        videoAsyncTask = new VideoAsyncTask(FullscreenActivity.this, videoView);
        videoAsyncTask.execute(link);

    }

    @Override
    public void onBackPressed() {
        videoAsyncTask.cancel(true);
        super.onBackPressed();
    }
}
