package com.example.videoviewdemo;

import android.app.Activity;
import android.app.ProgressDialog;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.MediaController;
import android.widget.VideoView;


public class VideoAsyncTask extends AsyncTask<String, Uri, Void> {
    Integer track = 0;
    ProgressDialog progressDialog;
    Activity activity;
    VideoView videoView;
    MediaController mediaController;

    public VideoAsyncTask(Activity callingActivity, VideoView callingView, MediaController controller) {
        super();
        activity = callingActivity;
        videoView = callingView;
        mediaController = controller;
    }

    public VideoAsyncTask(Activity callingActivity, VideoView callingView) {
        super();
        activity = callingActivity;
        videoView = callingView;
        mediaController = new MediaController(activity);
    }



    // handle the progress dialog
    protected void onPreExecute() {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Buffering video...");
        progressDialog.setCancelable(true);
        progressDialog.show();
    }

    // when video ready
    protected void onProgressUpdate(final Uri... uri) {

        try {

            videoView.setMediaController(mediaController);

            // timeout after 10000 ms
            mediaController.show(10000);

            videoView.setVideoURI(uri[0]);
            videoView.requestFocus();

            // listener for when video is prepared. Stop dialog
            videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {

                public void onPrepared(MediaPlayer arg0) {

                    // Note: if you wanted the video to autoplay, you would call start here
                    //videoView.start();

                    progressDialog.dismiss();
                }
            });

        } catch (IllegalArgumentException e) {
            Log.d("AndroidDev", "Message: " + e.getMessage() + ". Stack Trace: " + e.getStackTrace());
        } catch (IllegalStateException e) {
            Log.d("AndroidDev", "Message: " + e.getMessage() + ". Stack Trace: " + e.getStackTrace());
        } catch (SecurityException e) {
            Log.d("AndroidDev", "Message: " + e.getMessage() + ". Stack Trace: " + e.getStackTrace());
        }
    }

    @Override
    protected Void doInBackground(String... params) {

        try {
            Uri uri = Uri.parse(params[0]);
            publishProgress(uri);
        } catch (Exception e) {
            Log.d("AndroidDev", "Message: " + e.getMessage() + ". Stack Trace: " + e.getStackTrace());
        }

        return null;
    }
}